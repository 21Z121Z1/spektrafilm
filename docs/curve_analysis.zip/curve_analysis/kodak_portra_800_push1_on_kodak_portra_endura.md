# kodak_portra_800_push1 + kodak_portra_endura 曲线分析

## 组合基本数据
- **胶片 (Film)**: `kodak_portra_800_push1`
- **相纸 (Paper)**: `kodak_portra_endura`

## 全曲线数据指标
| 区域 | 指标名称 | 取值 | 描述 |
| :--- | :--- | :--- | :--- |
| **暗部/趾部** | Shadow Floor Y | `0.0728` | 极暗处的黑场基底亮度 (Dmin) |
| | Shadow Tint (Spread) | `0.0159` | 极暗处的 RGB 色偏程度 |
| | Toe Contrast | `0.1588` | 暗部上升斜率 |
| **中间调** | Midtone Contrast | `0.7078` | 主体对比度 (Gamma) |
| | Look White Y | `0.7530` | SDR 基准下的相纸白点 (Diffuse White) |
| **高光肩部** | Shoulder Y | `0.9136` | 极高光滚降到达的极限亮度 |
| | Highlight Contrast | `0.0107` | 极高光的压缩后斜率 |
| | Shoulder Tint (Spread)| `0.0080` | 极高光区域的通道衰减色偏 |

## 拟合数学公式 (5-Parameter Generalized Logistic Function)
为了追求更高的精确度，特别是为了拟合胶片曲线趾部 (Toe) 和肩部 (Shoulder) 的**不对称性**，我们采用了 5 参数的理查兹曲线 (Richards Curve) 进行高精度拟合（Y vs $\log_2(\text{scene\_luminance})$，即 EV）。
其理论曲线公式如下：
$$ Y(EV) = D_{min} + \frac{D_{max} - D_{min}}{(1 + \nu e^{-k(EV - EV_0)})^{\frac{1}{\nu}}} $$

**具体参数取值为：**
- **$D_{min}$ (暗部底色基准)** = `0.0688`
- **$D_{max}$ (高光极限量)** = `0.9168`
- **$k$ (反差/坡度)** = `1.0823`
- **$EV_0$ (曝光中点)** = `-1.3515`
- **$\nu$ (不对称系数)** = `0.7677`

> 这意味着，在 HDR 的数学推导中，您可以直接使用以下极高精度的函数来模拟或逆推 kodak_portra_800_push1 与 kodak_portra_endura 的全段亮度转移特性：
> $$ Y = 0.0688 + \frac{0.8480}{(1 + 0.7677 \cdot e^{-1.0823(EV - -1.3515)})^{\frac{1}{0.7677}}} $$

## 针对此组合的详细分析与 HDR 建议
### 1. 暗部表现 (Shadows)
该组合的暗部反差 (`0.1588`) 较平缓，暗部细节保留较多。

### 2. 中间调表现 (Midtones)
中间调对比度极高 (`0.7078`)。这意味着胶片将光线能量迅速推向了相纸的宽容度极限，使得画面反差强烈、色彩浓郁。

### 3. 高光与滚降 (Highlights & Rolloff)
在过曝区域，曲线依然保持着一定的攀升能力 (`0.0107`)，高光宽容度表现较好。
极高光的通道分离度适中 (`0.0080`)，三通道高光相对中性，非常适合进行激进的 HDR Diffuse Lift 映射，不易产生严重的色彩断层。